﻿using System;
using SadConsole;
using Microsoft.Xna.Framework;
using Console = SadConsole.Console;

namespace GpusoftRogue
{
    public static class Program
    {
        [STAThread]
        static void Main()
        {
            // Setup the engine and create the main window.
                SadConsole.Game.Create(80, 25);

                // Hook the start event so we can add consoles to the system.
                SadConsole.Game.OnInitialize = Init;

                // Start the game.
                SadConsole.Game.Instance.Run();
                SadConsole.Game.Instance.Dispose();
        }

        static void Init()
        {
            SadConsole.Global.LoadFont("Fonts/colored_transparent.font");
            var fontMaster = SadConsole.Global.Fonts["ColoredTransparent"];
           
            var normalSizedFont = fontMaster.GetFont(Font.FontSizes.One);


            var console = new Console(80, 25);
            console.FillWithRandomGarbage();
            console.Fill(new Rectangle(3, 3, 23, 3), Color.Violet, Color.Black, 0, 0);
            console.Print(4, 4, "Hello from SadConsole");
            console.Font = normalSizedFont;
            SadConsole.Global.CurrentScreen = console;
        }
    }
}
